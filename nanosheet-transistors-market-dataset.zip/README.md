# Nanosheet Transistors Market Dataset
This dataset is a structured representation of the public information from the Nanosheet Transistors Market report page on NextMSC.

## Contents
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- toc.txt

## License
MIT License
